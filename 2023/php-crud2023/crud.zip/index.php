<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registeration</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

    <section>
        <div class="container">
            <div class="form-wrap">
                <h1 class="title">Registeration</h1>
                <div class="form">
                    <form method="POST">
                        <div class="input-wrap">
                            <input type="text" placeholder="Name" name="name">
                        </div>
                        <div class="input-wrap">
                            <input type="text" placeholder="Email" name="email">
                        </div>
                        <div class="input-wrap">
                            <input type="text" placeholder="Phone" name="phone">
                        </div>
                        <div class="input-wrap">
                            <input type="text" placeholder="Password" name="password">
                        </div>
                        <div class="submit-wrap">
                            <input type="submit" value="Submit" name="submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <?php include("connection.php");?>
    <?php
        if(isset($_POST["submit"]))
        {
            $nameVal = $_POST["name"];
            $emailVal = $_POST["email"];
            $phoneVal = $_POST["phone"];
            $passwordVal = $_POST["password"];
            
            $sql = "INSERT INTO user_registeration(`name`, `email`, `phone`, `password`) VALUES ('$nameVal','$emailVal','$phoneVal','$passwordVal')";
            
            if (mysqli_query($conn, $sql)) {
                ?>
                <script>
                    alert("New record created successfully");
                </script>
                <?php
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }

            mysqli_close($conn);
        }
    ?>
</body>
</html>