<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Display</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

    <section>
        <div class="container">
            <div class="display-data">
                <h1 class="title">Registeration Data</h1>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>    
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Password</th>
                                <th>Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php include("connection.php");?>
                            <?php
                                $sql = "SELECT * FROM `user_registeration`";
                                $result = mysqli_query($conn, $sql);
                                
                                if (mysqli_num_rows($result) > 0) {
                                    // output data of each row
                                    while($row = mysqli_fetch_assoc($result)) {
                                    ?>
                                        <tr>
                                            <td><?php echo $row['id']?></td>
                                            <td><?php echo $row['name']?></td>
                                            <td><?php echo $row['email']?></td>
                                            <td><?php echo $row['phone']?></td>
                                            <td><?php echo $row['password']?></td>
                                            <td>
                                                <a href="./update.php?id=<?php echo $row['id']?>" class="operation">
                                                    <img src="./assets/img/edit.png" alt="edit">
                                                </a>
                                                <a href="./delete.php?id=<?php echo $row['id']?>" class="operation">
                                                    <img src="./assets/img/delete.png" alt="delete">
                                                </a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                } else {
                                echo "0 results";
                                }
                                
                                mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</body>
</html>