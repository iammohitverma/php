<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Information</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <?php include 'connection.php'?>
    <?php
        $id = $_GET['id'];
    ?>

</head>
<body>

    <section>
        <div class="container">
            <div class="form-wrap">
                <h1 class="title">Update Information</h1>
                <div class="form">
                    <form method="POST">
                        <?php
                            $sql = "SELECT id, name, email, phone, password FROM user_registeration WHERE id =  $id";
                            $result = mysqli_query($conn, $sql);
                            
                            if (mysqli_num_rows($result) > 0) {
                                $row = mysqli_fetch_assoc($result);
                                ?>
                                <div class="input-wrap">
                                    <input type="text" placeholder="Name" name="name" value="<?php echo $row['name'];?>">
                                </div>
                                <div class="input-wrap">
                                    <input type="text" placeholder="Email" name="email" value="<?php echo $row['email'];?>">
                                </div>
                                <div class="input-wrap">
                                    <input type="text" placeholder="Phone" name="phone" value="<?php echo $row['phone'];?>">
                                </div>
                                <div class="input-wrap">
                                    <input type="text" placeholder="Password" name="password" value="<?php echo $row['password'];?>">
                                </div>
                                <div class="submit-wrap">
                                    <input type="submit" value="Update" name="submit">
                                </div>
                                <?php
                            } else {
                            echo "0 results";
                            }
                            
                        ?>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        if(isset($_POST["submit"]))
        {
            $nameVal = $_POST["name"];
            $emailVal = $_POST["email"];
            $phoneVal = $_POST["phone"];
            $passwordVal = $_POST["password"];
            
            $sql = "UPDATE user_registeration SET name='$nameVal',email='$emailVal',phone='$phoneVal',password='$passwordVal' WHERE id = $id";
            
            if (mysqli_query($conn, $sql)) {
                ?>
                <script>
                    alert("Record updated successfully");
                </script>
                <?php
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }

            mysqli_close($conn);
            Header('Location: '.$_SERVER['PHP_SELF'] . '?id=' .$id);
        }
    ?>
</body>
</html>