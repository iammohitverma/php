<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Information</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <?php include 'connection.php'?>
    <?php
        $id = $_GET['id'];
    ?>
</head>
<body>

<?php
    // sql to delete a record
    $sql = "DELETE FROM user_registeration WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    } else {
    echo "Error deleting record: " . mysqli_error($conn);
    }

    mysqli_close($conn);
    $actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]/display.php";
    Header('Location: '. $actual_link );
?>
</body>
</html>